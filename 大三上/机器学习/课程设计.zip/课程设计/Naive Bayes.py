# coding=utf-8
import numpy as np
import matplotlib.pyplot as plt
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import (accuracy_score, log_loss, precision_recall_fscore_support)


train_data = np.loadtxt('experiment_05_training_set.csv',delimiter=',')
test_data = np.loadtxt('experiment_05_testing_set.csv',delimiter=',')
num_train = train_data.shape[0]
num_test = test_data.shape[0]
train_x = train_data[:,:-1]/255
train_y = train_data[:,-1]
test_x = test_data[:,:-1]/255
test_y = test_data[:,-1]

x_train,x_valid,y_train,y_valid = train_test_split(
    train_x,train_y,test_size=0.2,
    random_state=42
    )

model = MultinomialNB(
    alpha=1.0  
)

print("��ʼѵ�����ر�Ҷ˹ģ��")

model.fit(x_train, y_train)

y_train_pred = model.predict(x_train)    
y_train_proba = model.predict_proba(x_train)
y_val_pred = model.predict(x_valid)        
y_val_proba = model.predict_proba(x_valid)   

train_loss = log_loss(y_train, y_train_proba)
train_acc = accuracy_score(y_train, y_train_pred)
train_precision, train_recall, train_f1, _ = precision_recall_fscore_support(y_train, y_train_pred, average='macro')
    
val_loss = log_loss(y_valid, y_val_proba)
val_acc = accuracy_score(y_valid, y_val_pred)
val_precision, val_recall, val_f1, _ = precision_recall_fscore_support(y_valid, y_val_pred, average='macro')

print(f"ѵ������ʧ: {train_loss:.4f} ׼ȷ��: {train_acc:.4f} ��ȷ��: {train_precision:.4f} �ٻ���: {train_recall:.4f} F1ֵ: {train_f1:.4f}")
print(f"��֤����ʧ: {val_loss:.4f} ׼ȷ��: {val_acc:.4f} ��ȷ��: {val_precision:.4f} �ٻ���: {val_recall:.4f} F1ֵ: {val_f1:.4f}")
    

y_test_pred = model.predict(test_x)
y_test_proba = model.predict_proba(test_x)
test_loss = log_loss(test_y, y_test_proba)
test_acc = accuracy_score(test_y, y_test_pred)
test_precision, test_recall, test_f1, _ = precision_recall_fscore_support(
    test_y, y_test_pred, average='macro'
)
print("ѵ�������������ǲ��Լ����")
print(f"��ʧ: {test_loss:.4f} ׼ȷ��: {test_acc:.4f}")
print(f"��ȷ��: {test_precision:.4f} �ٻ���: {test_recall:.4f} F1ֵ: {test_f1:.4f}")
